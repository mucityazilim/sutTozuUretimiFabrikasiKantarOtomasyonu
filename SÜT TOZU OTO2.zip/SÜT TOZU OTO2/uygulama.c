#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
// Mucit Yaz�l�m- Sad�k �AH�N 

typedef struct Araclar {
	int numara,  urunCinsi ; 
	char plaka[20], sofor[20], geldigiYer[20]; 
	int ilkTartim, sonTartim; 	
	time_t girisTarihSaat, cikisTarihSaat; 
	int kilo, durum; 	
} arac  ;



void aracKantarGirisiYap() 
{
	system("cls") ; 
	printf("Urun Girisi icin Kantar giris islemi...  \n")  ; 
	arac a1; 
	int numara=0; 
	FILE *numPtr = fopen("aracNumaralari.dat", "a+b") ; 
	while(  fread ( &numara, sizeof(int), 1, numPtr ) !=NULL   )
	{		
	}
	numara++; 
	fwrite  ( &numara, sizeof(int), 1, numPtr ) ; 
	fclose(numPtr) ; 
		
	a1.numara= numara; 		
	printf("1- PAS \n") ;      // PAS = Peynir alt� suyu 
	printf("2- SUT \n") ; 
	printf("3- KONSANTRE \n") ; 
	printf("Urun Cinsi [1,2,3] : ") ; scanf(" %d", &a1.urunCinsi ) ; 
	printf("Plaka              : ") ; scanf(" %[^\n]s", a1.plaka ) ; 
	printf("Sofor Ad-Soyad     : ") ; scanf(" %[^\n]s", a1.sofor ) ; 
	printf("Geldigi Yer        : ") ; scanf(" %[^\n]s", a1.geldigiYer ) ; 
	printf("Ilk Tartim ( Kg.)  : ") ; scanf(" %d", &a1.ilkTartim ) ; 
	a1.sonTartim= 0; 
	a1.girisTarihSaat  = time(0) ; 
	a1.cikisTarihSaat= time(0) ; 
	a1.kilo= 0; 
	a1.durum= 0;
	
	
	FILE *ptr = fopen("urunGirisleri.dat", "a+b") ; 
	fwrite  ( &a1, sizeof( arac ), 1, ptr ) ;  
	fclose(ptr) ; 
	printf("Arac giris kaydi tamam \n") ; 	
	
}

void aracKantarCikisiYap() 
{
	system("cls") ; 
	printf("Urun Girisi icin Kantar cikis islemi...  \n")  ; 
	arac a1; 
	int numara, sonuc=0, sayac=0 ; 
	FILE *ptr = fopen("urunGirisleri.dat", "r+b") ; 
	while( fread  ( &a1, sizeof( arac ), 1, ptr )  !=NULL  )
	{
		if( a1.durum ==0  ) 
		sonuc= 1; 		
	}
	
	if(  sonuc ==0  )
	{
		printf("Bosaltimda bekleyen arac yok ! \n")  ; 
		fclose(ptr) ; 
	}
	else
	{
		rewind(ptr) ; 
		printf("%-10s%-20s%-20s \n", "NUMARA", "PLAKA", "ILK-TARTIM (kg)" ) ; 
		while( fread  ( &a1, sizeof( arac ), 1, ptr )  !=NULL  )
		{
			if( a1.durum ==0  ) 
			printf("%-10d%-20s%-20d \n", a1.numara, a1.plaka, a1.ilkTartim ) ;  			
		}
	
		
		printf("Cikis Yapacak Aracin Numarasi : ") ; scanf("%d", &numara ) ; 
		
		sonuc=0; 
		rewind( ptr) ; 
			while( fread  ( &a1, sizeof( arac ), 1, ptr )  !=NULL  )
			{
				if( a1.durum ==0 && a1.numara == numara   ) 
				{
					sonuc=1; 
					break; 
				}	
				sayac++; 				
			}
			
			if( sonuc==0 )
			printf( "%d numarali arac kaydi yok ! \n", numara   )  ; 
			else
			{
				printf("Son Tartim ( Kg.)  : ") ; scanf(" %d", &a1.sonTartim ) ; 
				a1.cikisTarihSaat= time(0) ; 
				a1.kilo=  a1.ilkTartim - a1.sonTartim ;  
				a1.durum= 1;
				
				fseek  ( ptr, (sayac) * sizeof( arac ), 0 )  ; 								
				fwrite  ( &a1, sizeof( arac ), 1, ptr ) ; 
				printf("Arac cikis kaydi tamam \n") ; 
							
			}
			
		fclose(ptr) ; 
	} 
	
}

void bosaltimdaBekleyenAraclar() 
{
	system("cls") ; 
	printf("Bosaltimda bekleyen araclar ...  \n")  ; 
	arac a1; 
	int numara, sonuc=0, sayac=0 ; 
	FILE *ptr = fopen("urunGirisleri.dat", "r+b") ; 
	while( fread  ( &a1, sizeof( arac ), 1, ptr )  !=NULL  )
	{
		if( a1.durum ==0  ) 
		sonuc= 1; 		
	}
	
	if(  sonuc ==0  )
	{
		printf("Bosaltimda bekleyen arac yok ! \n")  ; 
		fclose(ptr) ; 
	}
	else
	{
		rewind(ptr) ; 
		printf("%-10s%-20s%-20s \n", "NUMARA", "PLAKA", "ILK-TARTIM (kg)" ) ; 
		while( fread  ( &a1, sizeof( arac ), 1, ptr )  !=NULL  )
		{
			if( a1.durum ==0  ) 
			printf("%-10d%-20s%-20d \n", a1.numara, a1.plaka, a1.ilkTartim ) ;  			
		} 	
		fclose(ptr) ; 
	} 
	
}

void urunGirisleriniRaporla ()
{
	system("cls") ; 
	printf("Ham madde giris raporlari ...  \n")  ; 
	arac a1; 
	int numara, sonuc=0, sayac=0, sutToplam=0, pasToplam=0, konsantreToplam=0 ; 
	FILE *ptr = fopen("urunGirisleri.dat", "r+b") ; 
	while( fread  ( &a1, sizeof( arac ), 1, ptr )  !=NULL  )
	{
		if( a1.durum ==1  ) 
		sonuc= 1; 		
	}
	
	if(  sonuc ==0  )
	{
		printf("Ham madde teslimati olmamistir ! \n")  ; 
		fclose(ptr) ; 
	}
	else
	{
		system("cls") ; 
		
		rewind(ptr) ; 
		printf("%-10s%-20s%-20s%-20s%-20s \n", "NUMARA", "PLAKA", "ILK-TARTIM (kg)", "SON-TARTIM (kg)", "NET-KILO (kg)" ) ; 
		while( fread  ( &a1, sizeof( arac ), 1, ptr )  !=NULL  )
		{
			if( a1.durum ==1  ) 
			printf("%-10d%-20s%-20d%-20d%-20d\n", a1.numara, a1.plaka, a1.ilkTartim, a1.sonTartim, a1.kilo  ) ;  			
			
			
			if( a1.urunCinsi==1 )
			pasToplam += a1.kilo ; 
			else if( a1.urunCinsi == 2 )
			sutToplam += a1.kilo; 
			else if ( a1.urunCinsi== 3  ) 
			konsantreToplam += a1.kilo; 			
		} 	
		fclose(ptr) ; 
		
		printf("\n\n Toplam Sonuclar \n\n") ; 
		printf("PAS           : %d  kg. \n", pasToplam ) ; 
		printf("SUT           : %d  kg. \n", sutToplam ) ; 
		printf("KONSANTRE     : %d  kg. \n\n\n", konsantreToplam ) ; 		
	} 	
}



int urunGirisMenu() 
{
	int secim; 
	
	printf("\n\tURUN GIRIS ISLEMLERI \n\n") ; 
 	
	printf("\t1-  Arac Kantar Girisi Yap \n\n "); 
	printf("\t2-  Arac Kantar Cikisi Yap \n\n "); 
	printf("\t3-  Bosaltimda Bekleyen Araclar \n\n "); 
	printf("\t4-  Urun Girislerini Raporla \n\n "); 	
	printf("\t0- Anamenuye Don \n\n "); 
	printf("\tSeciminiz : ") ; scanf("%d", &secim  ) ; 
	system("cls") ; 
	return secim; 
	
}





void urunGirisIslemleri() 
{
	int secim= urunGirisMenu() ;  
	while( secim != 0)
	{
		switch(secim )
		{
			case 1:  aracKantarGirisiYap() ; break; 
			case 2:  aracKantarCikisiYap() ; break; 
			case 3:  bosaltimdaBekleyenAraclar() ; break; 
			case 4:  urunGirisleriniRaporla () ; break; 
			
			case 0: break; 
			default : printf("Hatali secim ! \n") ; break; 
		}
		secim= urunGirisMenu() ; 		
	}
	system("cls") ; 
	printf("Anamenuye donuluyor... \n\n") ;  
	
	
	
}

void aracKantarGirisiYap2 () 
{
	system("cls") ; 
	printf("Urun Satisi icin Kantar giris islemi...  \n")  ; 
	arac a1; 
	int numara=0; 
	FILE *numPtr = fopen("aracNumaralari2.dat", "a+b") ; 
	while(  fread ( &numara, sizeof(int), 1, numPtr ) !=NULL   )
	{		
	}
	numara++; 
	fwrite  ( &numara, sizeof(int), 1, numPtr ) ; 
	fclose(numPtr) ; 
		
	a1.numara= numara; 	
		
	printf("1- SUT TOZU \n") ; 
	printf("2- KREMA \n") ; 
	
	printf("Urun Cinsi [1,2 ] : ") ; scanf(" %d", &a1.urunCinsi ) ; 
	printf("Plaka              : ") ; scanf(" %[^\n]s", a1.plaka ) ; 
	printf("Sofor Ad-Soyad     : ") ; scanf(" %[^\n]s", a1.sofor ) ; 
	printf("Gidecegi Yer        : ") ; scanf(" %[^\n]s", a1.geldigiYer ) ; 
	printf("Ilk Tartim ( Kg.)  : ") ; scanf(" %d", &a1.ilkTartim ) ; 
	a1.sonTartim= 0; 
	a1.girisTarihSaat  = time(0) ; 
	a1.cikisTarihSaat= time(0) ; 
	a1.kilo= 0; 
	a1.durum= 0;
	
	
	FILE *ptr = fopen("urunCikislari.dat", "a+b") ; 
	fwrite  ( &a1, sizeof( arac ), 1, ptr ) ;  
	fclose(ptr) ; 
	printf("Arac giris kaydi tamam \n") ; 
	
}
void aracKantarCikisiYap2 () 
{
	system("cls") ; 
	printf("Urun Satisi icin Kantar cikis islemi...  \n")  ; 
	arac a1; 
	int numara, sonuc=0, sayac=0 ; 
	FILE *ptr = fopen("urunCikislari.dat", "r+b") ; 
	while( fread  ( &a1, sizeof( arac ), 1, ptr )  !=NULL  )
	{
		if( a1.durum ==0  ) 
		sonuc= 1; 		
	}
	
	if(  sonuc ==0  )
	{
		printf("Yuklemede bekleyen arac yok ! \n")  ; 
		fclose(ptr) ; 
	}
	else
	{
		rewind(ptr) ; 
		printf("%-10s%-20s%-20s \n", "NUMARA", "PLAKA", "ILK-TARTIM (kg)" ) ; 
		while( fread  ( &a1, sizeof( arac ), 1, ptr )  !=NULL  )
		{
			if( a1.durum ==0  ) 
			printf("%-10d%-20s%-20d \n", a1.numara, a1.plaka, a1.ilkTartim ) ;  			
		}
	
		
		printf("Cikis Yapacak Aracin Numarasi : ") ; scanf("%d", &numara ) ; 
		
		sonuc=0; 
		rewind( ptr) ; 
			while( fread  ( &a1, sizeof( arac ), 1, ptr )  !=NULL  )
			{
				if( a1.durum ==0 && a1.numara == numara   ) 
				{
					sonuc=1; 
					break; 
				}	
				sayac++; 				
			}
			
			if( sonuc==0 )
			printf( "%d numarali arac kaydi yok ! \n", numara   )  ; 
			else
			{
				printf("Son Tartim ( Kg.)  : ") ; scanf(" %d", &a1.sonTartim ) ; 
				a1.cikisTarihSaat= time(0) ; 
				a1.kilo=  a1.sonTartim - a1.ilkTartim ;  
				a1.durum= 1;
				
				fseek  ( ptr, (sayac) * sizeof( arac ), 0 )  ; 								
				fwrite  ( &a1, sizeof( arac ), 1, ptr ) ; 
				printf("Arac cikis kaydi tamam \n") ; 
							
			}
			
		fclose(ptr) ; 
	} 	
	
}

void yuklemedeBekleyenAraclar() 
{
	system("cls") ; 
	printf("Yuklemede bekleyen araclar ...  \n")  ; 
	arac a1; 
	int numara, sonuc=0, sayac=0 ; 
	FILE *ptr = fopen("urunCikislari.dat", "r+b") ; 
	while( fread  ( &a1, sizeof( arac ), 1, ptr )  !=NULL  )
	{
		if( a1.durum ==0  ) 
		sonuc= 1; 		
	}
	
	if(  sonuc ==0  )
	{
		printf("Yuklemede bekleyen arac yok ! \n")  ; 
		fclose(ptr) ; 
	}
	else
	{
		rewind(ptr) ; 
		printf("%-10s%-20s%-20s \n", "NUMARA", "PLAKA", "ILK-TARTIM (kg)" ) ; 
		while( fread  ( &a1, sizeof( arac ), 1, ptr )  !=NULL  )
		{
			if( a1.durum ==0  ) 
			printf("%-10d%-20s%-20d \n", a1.numara, a1.plaka, a1.ilkTartim ) ;  			
		} 	
		fclose(ptr) ; 
	} 
		
	
}

void satisiYapilanUrunleriRaporla () 
{
	system("cls") ; 
	printf("Satilan Urunlerin cikis raporu ...  \n")  ; 
	arac a1; 
	int numara, sonuc=0, sayac=0, sutTozuToplam=0, kremaToplam=0 ; 
	FILE *ptr = fopen("urunCikislari.dat", "r+b") ; 
	while( fread  ( &a1, sizeof( arac ), 1, ptr )  !=NULL  )
	{
		if( a1.durum ==1  ) 
		sonuc= 1; 		
	}
	
	if(  sonuc ==0  )
	{
		printf("Urun satisi (cikis) olmamistir ! \n")  ; 
		fclose(ptr) ; 
	}
	else
	{
		system("cls") ; 
		
		rewind(ptr) ; 
		printf("%-10s%-20s%-20s%-20s%-20s \n", "NUMARA", "PLAKA", "ILK-TARTIM (kg)", "SON-TARTIM (kg)", "NET-KILO (kg)" ) ; 
		while( fread  ( &a1, sizeof( arac ), 1, ptr )  !=NULL  )
		{
			if( a1.durum ==1  ) 
			printf("%-10d%-20s%-20d%-20d%-20d\n", a1.numara, a1.plaka, a1.ilkTartim, a1.sonTartim, a1.kilo  ) ;  			
			
			
			if( a1.urunCinsi==1 )
			sutTozuToplam += a1.kilo ; 
			else if( a1.urunCinsi == 2 )
			kremaToplam += a1.kilo; 
		} 	
		fclose(ptr) ; 
		
		printf("\n\n Toplam Sonuclar \n\n") ; 
		printf("SUT TOZU        : %d  kg. \n", sutTozuToplam ) ; 
		printf("KREMA           : %d  kg. \n\n\n", kremaToplam ) ; 		
	} 		
}



int urunCikisMenu()      // �retilmi� - sat��a sunulmu� �r�n 
{
	int secim; 
	
	printf("\n\tURUN CIKIS ISLEMLERI \n\n") ; 
 	
	printf("\t1-  Arac Kantar Girisi Yap \n\n "); 
	printf("\t2-  Arac Kantar Cikisi Yap \n\n "); 
	printf("\t3-  Yuklemede Bekleyen Araclar \n\n "); 
	printf("\t4-  Satisi Yapilan Urunleri Raporla \n\n "); 	
	printf("\t0- Anamenuye Don \n\n "); 
	printf("\tSeciminiz : ") ; scanf("%d", &secim  ) ; 
	system("cls") ; 
	return secim; 
	
}




void urunCikisIslemleri()
{
	int secim= urunCikisMenu() ;  
	while( secim != 0)
	{
		switch(secim )
		{
			case 1:  aracKantarGirisiYap2 () ; break; 
			case 2:  aracKantarCikisiYap2 () ; break; 
			case 3:  yuklemedeBekleyenAraclar() ; break; 
			case 4:  satisiYapilanUrunleriRaporla () ; break; 
			
			case 0: break; 
			default : printf("Hatali secim ! \n") ; break; 
		}
		secim= urunCikisMenu() ; 		
	}
	system("cls") ; 
	printf("Anamenuye donuluyor... \n\n") ;  
	
	
	
}

int menu() 
{
	int secim; 
	
	printf("\n\tSUT TOZU- KREMA IMALAT FABRIKASI \n\n") ; 
	printf("\t      KANTAR OTOMASYONU \n\n\n") ; 
	
	printf("\t1- URUN GIRIS ISLEMLERI \n\n "); 
	printf("\t2- URUN CIKIS ISLEMLERI \n\n "); 
	printf("\t0- PROGRAMI KAPAT  \n\n "); 
	printf("\tSeciminiz : ") ; scanf("%d", &secim  ) ; 
	system("cls") ; 
	return secim; 
	
}



int main() 
{
	int secim= menu(); 
	while( secim != 0)
	{
		switch(secim )
		{
			case 1: urunGirisIslemleri(); break; 
			case 2: urunCikisIslemleri(); break; 
			case 0: break; 
			default : printf("Hatali secim ! \n") ; break; 
		}
		secim= menu(); 		
	}
	
	printf("Program kapatiliyor... ") ; 
	
	
	return 0; 	
}



